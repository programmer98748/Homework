from django.shortcuts import render

from dashboard.models import Posts , Category, Image, User, InformaionSite
# Create your views here.

def index(request): 
    information_site = InformaionSite.objects.all()
    images = Image.objects.all()
    posts = Posts.objects.all()
    context = {
        'infor_site':information_site,
        'images':images,
        'posts':posts,
    }
    return render(request, 'g/Creative-rtl.html', context)