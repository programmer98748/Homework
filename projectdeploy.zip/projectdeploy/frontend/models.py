from django.db import models

# Create your models here.


'''
class Category(models.Model):
    kk  = models.PointField()
   
    
    create_at = models.DateTimeField(auto_now=True)
'''
