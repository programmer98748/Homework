from django.urls import path, re_path
from . import views

from django.contrib.auth.views import LogoutView

from django.contrib.auth import views as auth_views


app_name = 'home' 

urlpatterns = [ 
    #path('login/', views.login_view, name="login"),
    path('', views.index, name='home'),
  #  re_path(r'^.*\.*', views.pages, name='pages'),

    ###
    #path('informaion_site/', views.informaion_site, name='informaion_site'), 
    path('informaion_site/', views.edite_informaion, name='informaion_site'),
   
   ###
    path('posts/', views.posts, name='posts'),
    path('posts/delete/<int:id>/', views.posts_delete, name='posts_delete'),
    path('posts/create/', views.post_add, name="post_create"),
    path('posts/edite/<int:id>/', views.post_edite, name='post_edite'),

  ###
    path('category/delete/<int:myid>/', views.categor_delete, name='category_delete'),
    path('category/edite/<int:id>/', views.category_edite, name='category_edite'),
    path('category/', views.category, name='category'),
   
   ###
   # path('user/', views.user_show, name='users'),
    #path('user/create', views.user_create, name='user_create'),
   # path('user/edite/<int:id>/', views.user_edite, name='user_edite'),
   # path('user/delete/<int:id>/', views.user_delete, name='user_delete'),

    ###
    path('profile/', views.profile, name='profile'),
    
    #path('register/', views.register_user, name="register"), LogoutView.as_view(),
    path("logout/", views.auth_logout, name="logout"),

    ###
    path('gallery/', views.gallery, name='gallery'),
   # path('gallery/add', views.gallery_add, name='gallery_add'),
    path('gallery/delete/<int:myid>/', views.gallery_delete, name='gallery_delete'),

    ###
    path('project/', views.project, name='project'),
    path('project/add', views.project_add, name='project_add'),
    path('project/edite/<int:id>/', views.project_edite, name='project_edite'),
    path('project/delete/<int:id>/', views.project_delete, name='project_delete'),


    path('aluser/<int:pk>', views.AEditUser.as_view(), name='user_edite'),

   
    path('aluser/', views.user_show, name='aluser'),
    #path('aluser/', views.ListUserView.as_view(), name='aluser'),
    path('create_use/', views.create_user, name='create_user_form'),
    path('alvuser/<int:pk>', views.ALViewUser.as_view(), name='alvuser'),
    path('aeuser/<int:pk>', views.AEditUser.as_view(), name='aeuser'),
    path('aduser/<int:pk>', views.ADeleteUser.as_view(), name='aduser'),

]




