from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from .forms import *

from django.contrib.auth.models import User
from django.contrib.messages.views import SuccessMessageMixin

from django import template
from django.views import generic

from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse

from django.contrib.auth.decorators import login_required

from django.views.decorators.http import require_POST

from .models import Posts , Category, Image

from django.contrib import auth, messages
from django.contrib.auth.hashers import make_password
from django.contrib.auth.mixins import LoginRequiredMixin


from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView, PasswordResetView, PasswordChangeView

from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Sum
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.views.generic import CreateView, DetailView, DeleteView, UpdateView, ListView

from . import models
import operator
import itertools
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth import authenticate, logout
from django.contrib import auth, messages
from django.contrib.auth.hashers import make_password
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.utils import timezone




def index(request):
    if request.user.is_authenticated:
        user = request.user.username #.id
        #user = User.bject.all
        #user = User.bject.get(id=request.user.id)
        #{{user.last_login }} last time
        return render(request, 'index.html')

    else:
        return HttpResponseRedirect('/dashboard/login') 


####### post ###

@login_required(login_url='dashboard/login')
#@allowed_users(allowed_roles=['Admin'])
def posts(request):
    post = Posts.objects.all()
    context = { 'post': post }
    return render(request, 'dashboard/post.html', context)


@login_required(login_url='dashboard/login')
def post_add(request):

    if request.method == "POST":
        form = PostsForm(request.POST, request.FILES )
        if form.is_valid():
            form.save()
            messages.success(request, f"تم الاضافة  بنجاح") 
            return redirect(reverse('dashboard:posts'))
   

    else:
        form = PostsForm()

    context={
        'form':form,
    
    }

    return render(request, 'dashboard/post_create.html', context)

@login_required(login_url='dashboard/login')
#@require_POST
def posts_delete(request, id):
    
    product = Posts.objects.get(id=id)
    product.delete()
    messages.success(request, f"تم الحذف بنجاح") 

    return redirect(reverse('dashboard:posts'))

@login_required
def post_edite(request, id):
    posts = get_object_or_404(Posts, id=id)
    if request.method == "POST":

        form = PostsForm(request.POST, instance=posts)
        if form.is_valid():
            form.save()
            messages.success(request, f' لقد تم حفظ التعديل بنجاح') 
          
            return HttpResponseRedirect('/dashboard/posts') 
    else:
        form = PostsForm(instance=posts)
    

    context = {
        'form':form
    }    
   
    return render(request, 'dashboard/post_edite.html',context)






     ##### category ##

@login_required
def category(request):
    
    category = Category.objects.all()

    if request.method == 'POST':
        name = request.POST['name']
        user_id = request.user.id
        a = Category(name=name)
        a.save() 
        messages.success(request, f"تم الح\ف ب") 



    return render(request,'page/category.html', {'category':category})

def category_edite(request, id):
    formm = Category.objects.get(id=id)
    if request.method == "POST":
        form = CategoryForm(request.POST, instance=formm)
        if form.is_valid():
            form.save()
            messages.success(request, f' لقد تم حفظ التعديل بنجاح') 
          
            return HttpResponseRedirect('/dashboard/category') 
    else:
        form = CategoryForm(instance=formm)

    return render(request,'page/category_edite.html', {'form':form})

@login_required
def categor_delete(request, myid):
    
    product = Category.objects.get(id=myid)

    product.delete()
    messages.success(request, f"  تم الحذف بنجاح") 

    return redirect(reverse('dashboard:category'))




######### gallery ####
@login_required
def gallery(request):
    categories = Category.objects.all()
   # orders = Image.objects.all() 
    #myFilter = OrderFilter(request.GET, queryset=orders)
   # orders = myFilter.qs




    category = request.GET.get('category')
    if category is None:
        images = Image.objects.all()
    
    else:
        images = Image.objects.filter(category__category_name=category)
        

    if request.method == 'POST':
        form= PhotosForm(request.POST, request.FILES)
       
        if form.is_valid():
            myform = form.save(commit=False)
            myform.owner = request.user
            myform.save()
            messages.success(request, f"تم الاضافة  بنجاح") 
            return redirect(reverse('dashboard:gallery'))

    
    else:
        form = PhotosForm()
        print('hhhh')

 
        
  

    context = { 'photos':images  ,'categories':categories,'form':form }
    return render(request, 'dashboard/gallery.html', context )

@login_required
def gallery_delete(request, myid):
    
    product = Image.objects.get(id=myid)

    product.delete()
    messages.success(request, f"تم الحذف بنجاح") 
    
    return redirect(reverse('dashboard:gallery'))


##### project ###3
@login_required  
def project(request):
    category = Category.objects.all()

    context = {'category':category}
    return render(request, 'dashboard/projects.html', context)

@login_required
def project_add(request):
    #formm = Category.objects.get(id=id)
    if request.method == "POST":
        form = CategoryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, f' لقد تم حفظ التعديل بنجاح') 

            return HttpResponseRedirect('/dashboard/project') 
    else:
        form = CategoryForm()
    context={
        'form':form,
    
    }

    return render(request, 'dashboard/project_add.html', context)

@login_required
def project_edite(request, id ):
    formm = Category.objects.get(id=id)
    if request.method == "POST":
        form = CategoryForm(request.POST, request.FILES, instance=formm)
        if form.is_valid():
            form.save()
            messages.success(request, f' لقد تم حفظ التعديل بنجاح') 

            return HttpResponseRedirect('/dashboard/project') 
    else:
        form = CategoryForm(instance=formm)
    context={
        'form':form,
    
    }

    return render(request, 'dashboard/project_edite.html', context)

@login_required
def project_delete(request, id):
    
    product = Category.objects.get(id=id)

    product.delete()
    messages.success(request, f"  تم الحذف بنجاح") 

    return redirect(reverse('dashboard:project'))



#### login ######

@login_required
def auth_logout(request):
    logout(request)
    return HttpResponseRedirect('/dashboard/login')



##### profile #####

#@login_required(login_url="/login/")
@login_required
def profile(request):
    if request.method == 'POST':
        user_form = UpdateUserForm(request.POST, instance=request.user)
        profile_form = UpdateProfileForm(request.POST, request.FILES, instance=request.user.profile)

        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Your profile is updated successfully')
            return redirect(to='dashboard:profile')
    else:
        user_form = UpdateUserForm(instance=request.user)
        profile_form = UpdateProfileForm(instance=request.user.profile)

    return render(request, 'users/profile.html', {'user_form': user_form, 'profile_form': profile_form})



###### users ###
@login_required

def edite_informaion(request):
    
    form_id = InformaionSite.objects.first()
    if request.method == 'POST':
        form_infor = InformaionSiteForm(request.POST,request.FILES, instance=form_id)
        if form_infor.is_valid():
            form_infor.save()
            messages.success(request, f"تم التعديل  بنجاح") 
    else:
        form_infor = InformaionSiteForm(instance=form_id)     
        
        

    context = {
        'form':form_infor,
    }
       
    return render(request, 'dashboard/edit_information.html', context)




#@login_required
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('users/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('users/page-500.html')
        return HttpResponse(html_template.render(context, request))






class ADeleteUser(SuccessMessageMixin, DeleteView):
    model = User
    template_name='dashboard/confirm_delete3.html'
    success_url = reverse_lazy('dashboard:aluser')
    success_message = "Data successfully deleted"


class AEditUser(SuccessMessageMixin, UpdateView): 
    model = User
    form_class = UserForm
    template_name = 'dashboard/edit_user.html'
    success_url = reverse_lazy('dashboard:aluser')
    success_message = "Data successfully updated"

@login_required(login_url='')
def user_show(request):
    users = User.objects.all()

    if request.method == "POST":
        active = request.POST.get('active')
        if active == '1':
            active = True

        else:
            active = False

        user_id= title = request.POST.get('user_id')
        user = User.objects.get(id=user_id)
        
        
        user.is_staff =  active
        user.is_active = active
        user.is_superuser = active
        
        user.save()
        

    context = { 'users': users }
    return render(request, 'dashboard/list_users.html', context)


class ChangePasswordView(SuccessMessageMixin, PasswordChangeView):
    template_name = 'users/change_password.html'
    success_message = "Successfully Changed Your Password"
    success_url = reverse_lazy('users-home')


class ALViewUser(DetailView):
    model = User
    template_name='dashboard/user_detail.html'
 




@login_required
def create_user(request):
    msg = None
    success = False

    if request.method == "POST":
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")
            user = authenticate(username=username, password=raw_password)
            msg = 'User created - please <a href="/login">login</a>.'
            success = True

            return redirect("/dashboard/aluser")

        else:
            msg = 'Form is not valid'
    else:
        form = CreateUserForm()

    return render(request, "users/user__create.html", {"form": form, "msg": msg, "success": success})
 
